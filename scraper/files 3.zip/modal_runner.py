"""
runtime/modal_runner.py

Deploy the workflow executor to Modal for:
- Cloud execution (no local browser needed)
- Parallelizing across date ranges / filter sets
- Scheduled runs via Modal's cron support
- REST endpoint for triggering runs

Deploy:
    modal deploy modal_runner.py

Run once:
    modal run modal_runner.py::run_workflow --schema-path schema.json

Schedule:
    Add @app.function(schedule=modal.Cron("0 6 * * *")) decorator
"""

import modal
import json
import os
from pathlib import Path

# ─── Modal App Setup ────────────────────────────────────────────────────────

app = modal.App("web-automation")

# Image with Playwright + all browsers
playwright_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "playwright",
        "anthropic",
        "asyncpg",       # If using Postgres
    )
    .run_commands(
        "playwright install chromium",
        "playwright install-deps chromium",
    )
)


# ─── Core Worker Function ────────────────────────────────────────────────────

@app.function(
    image=playwright_image,
    secrets=[
        modal.Secret.from_name("db-credentials"),
        modal.Secret.from_name("anthropic-api-key"),
    ],
    timeout=3600,           # 1 hour max per run
    memory=2048,            # 2GB RAM for browser + screenshots
    cpu=2,
)
async def run_workflow(
    schema: dict,
    params: dict = {},
    headless: bool = True,
) -> dict:
    """Execute a workflow schema on Modal."""
    import sys
    sys.path.insert(0, "/root")

    from runtime.executor import WorkflowExecutor

    executor = WorkflowExecutor(schema, params)
    await executor.run(headless=headless)

    return executor.stats


# ─── Parallelized Date Range Runner ─────────────────────────────────────────

@app.function(
    image=playwright_image,
    secrets=[
        modal.Secret.from_name("db-credentials"),
        modal.Secret.from_name("anthropic-api-key"),
    ],
    timeout=7200,
)
async def run_parallel_date_ranges(
    schema: dict,
    date_ranges: list[dict],
    max_parallel: int = 5,
) -> list[dict]:
    """
    Run the same schema across multiple date ranges in parallel.

    date_ranges example:
    [
      {"startDate": "2024-01-01", "endDate": "2024-03-31"},
      {"startDate": "2024-04-01", "endDate": "2024-06-30"},
      ...
    ]
    """
    import asyncio

    sem = asyncio.Semaphore(max_parallel)

    async def run_one(params):
        async with sem:
            return await run_workflow.remote.aio(schema, params)

    tasks  = [run_one(p) for p in date_ranges]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    return [
        {"params": p, "result": r if not isinstance(r, Exception) else {"error": str(r)}}
        for p, r in zip(date_ranges, results)
    ]


# ─── REST Endpoint ──────────────────────────────────────────────────────────

@app.function(
    image=playwright_image,
    secrets=[
        modal.Secret.from_name("db-credentials"),
        modal.Secret.from_name("anthropic-api-key"),
    ],
)
@modal.web_endpoint(method="POST")
async def trigger_workflow(request: dict) -> dict:
    """
    REST endpoint to trigger a workflow run.

    POST body:
    {
      "schema": { ... },      // or "schemaName": "registered_schema_key"
      "params": { ... },
      "async": false          // true = fire-and-forget
    }
    """
    schema = request.get("schema")
    params = request.get("params", {})
    async_run = request.get("async", False)

    if not schema:
        return {"error": "schema required"}, 400

    if async_run:
        run_workflow.spawn(schema, params)
        return {"status": "queued"}
    else:
        stats = await run_workflow.remote.aio(schema, params)
        return {"status": "complete", "stats": stats}


# ─── Scheduled Run Example ──────────────────────────────────────────────────

# Uncomment to run every weekday at 6am UTC:
# @app.function(
#     image=playwright_image,
#     schedule=modal.Cron("0 6 * * 1-5"),
#     secrets=[...],
# )
# async def scheduled_daily_run():
#     schema = json.loads(Path("schema.json").read_text())
#     from datetime import date, timedelta
#     today     = date.today()
#     yesterday = today - timedelta(days=1)
#     params    = {
#         "startDate": str(yesterday),
#         "endDate":   str(today),
#     }
#     await run_workflow.remote.aio(schema, params)


# ─── Local Test Entry ────────────────────────────────────────────────────────

@app.local_entrypoint()
def main(schema_path: str = "schema.json", params_path: str = ""):
    schema = json.loads(Path(schema_path).read_text())
    params = json.loads(Path(params_path).read_text()) if params_path else {}

    print("Running on Modal...")
    stats = run_workflow.remote(schema, params)
    print(f"Done: {stats}")
